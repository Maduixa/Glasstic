# Project memory: iOS 26+ LiquidGlass + watchOS 26+ companion + HealthKit + on‑device ML

## Operating assumptions
- You are working in a multi‑target Xcode project:
  - iOS app target
  - watchOS app target
  - (optional) widget/complication target
- Prefer SwiftUI + async/await + modern APIs.
- This repo targets **developer betas**; verify APIs against local SDK headers before committing to an approach.

## Where to look
- LiquidGlass: `docs/liquidglass/` (skill: `/liquidglass-ui`)
- watchOS companion: `docs/watch/` (skill: `/watch-connectivity`)
- HealthKit: `docs/healthkit/` (skill: `/healthkit-integration`)
- On-device ML: `docs/ondevice-ml/` (skill: `/ondevice-ml`)
- Agentic workflows: `docs/workflows/` (skill: `/scaffold-ios-watch`)
- Testing + compliance: `docs/testing/`, `docs/compliance/` (skills: `/test-strategy`, `/appstore-submission`)

## Default workflow
1) Clarify feature intent + constraints
2) Plan file‑level changes (list files to create/edit)
3) Implement minimal slice
4) Build + run + test
5) Harden: perf/accessibility/privacy
6) Commit small

## Commands (edit for your repo)
- iOS sim build:
  `xcodebuild -scheme <AppScheme> -destination 'platform=iOS Simulator,name=iPhone 16' build`
- watchOS sim build:
  `xcodebuild -scheme <WatchScheme> -destination 'platform=watchOS Simulator,name=Apple Watch Series 10 (46mm)' build`

## Guardrails
- No private APIs.
- Health data must be minimized and processed on‑device unless explicitly requested otherwise.
- LiquidGlass: avoid stacking/transparency abuse; use containers; test Reduce Transparency and contrast.
