# LiquidGlass SwiftUI cheat sheet (beta‑ready)

## Patterns

### Glass card (iOS first)
```swift
struct GlassCard: View {
  var body: some View {
    VStack(alignment: .leading, spacing: 6) {
      Text("Title").font(.headline)
      Text("Value").font(.title2).fontWeight(.semibold)
    }
    .padding(12)
    .background {
      if #available(iOS 26.0, *) {
        RoundedRectangle(cornerRadius: 16)
          .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 16))
      } else {
        RoundedRectangle(cornerRadius: 16).fill(.ultraThinMaterial)
      }
    }
  }
}
```

### Grouped glass controls
Use a container when several glass elements share the same backdrop:
```swift
GlassEffectContainer {
  HStack {
    Button("A") {}
    Button("B") {}
  }
}
```

### watchOS control style
```swift
Button("Start") { }
  .buttonStyle(.glass) // verify availability/signature in watchOS 26 SDK
```

## Reality checks (recommended)
- Use Xcode “Open Quickly” to locate the symbol: `glassEffect` / `GlassEffectContainer` / `Glass`.
- Compile a scratch snippet in a new target.
- Use `scripts/sdk_verify.sh` to grep the SwiftUI swiftinterface.
