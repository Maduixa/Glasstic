# iOS 26+ LiquidGlass + watchOS 26+ HealthKit + On‑Device AI — Claude Code Kit

This is a **drop‑in repository kit** for running **agentic, prompt‑driven development** with **Claude Code** on iOS 26+ / watchOS 26+ projects that use:

- LiquidGlass design system (SwiftUI)
- Apple Watch companion architecture (WatchConnectivity, complications/widgets)
- HealthKit (authorization, queries, workouts, background delivery)
- On‑device ML (Core ML + Vision/NLP/SoundAnalysis patterns)

## Install

Unzip into the **root of your existing repo** (it will create `.claude/`, `docs/`, `examples/`, `templates/`, `scripts/`).

```bash
unzip ios26-claude-code-kit.zip -d .
```

If you are starting a new repo, you can also unzip into an empty directory.

## How to use in Claude Code

From the repo root:

1. Start Claude Code:
   ```bash
   claude
   ```
2. Check memory (should include `CLAUDE.md` + `.claude/rules/*`):
   ```
   /memory
   ```
3. Use skills (slash commands):
   - `/scaffold-ios-watch` — plan + scaffold file structure
   - `/liquidglass-ui` — generate LiquidGlass components + fallbacks
   - `/healthkit-integration` — entitlements, Info.plist strings, auth + queries
   - `/watch-connectivity` — WCSession patterns + sync flows
   - `/ondevice-ml` — Core ML integration + on-device pipelines
   - `/appstore-submission` — review checklist for health + AI apps
   - `/test-strategy` — tests, snapshot checks, accessibility audit

4. Use specialist subagents (optional):
   ```
   /agents
   ```

## What’s in here

- `CLAUDE.md`: routing “map” for the project (kept intentionally short).
- `.claude/rules/`: always‑loaded rules (style, platform constraints, compliance).
- `.claude/skills/`: task‑oriented prompts as reusable workflows.
- `.claude/agents/`: domain specialists (UI, HealthKit, watchOS, ML, reviewer).
- `docs/`: the full guide split by domain (LiquidGlass, HealthKit, etc.).
- `examples/`: minimal code snippets (copy into your Xcode project and adjust).
- `templates/`: entitlements + Info.plist string templates.
- `scripts/`: optional verification helpers (SDK grep, build commands).

## Forward‑looking / beta notes

This kit is optimized for **developer betas** and forward‑looking workflows.
Treat all platform APIs as **“verify against your local SDK headers”** — the skills include a “Reality Check” step (grep SDK / compile) before you lock in implementation.

## License

MIT (see `LICENSE`).
